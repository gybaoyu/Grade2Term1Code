a = input("输入一个三位整数")
a = int(a)
b = a//100
c = (a%100)//10
d = a%100%10
print(f"{b}  {c}  {d}")

