length, width = input("input length and width: ").split()
length = int(length)
width = int(width)
print(f"the size is {length*width}")
