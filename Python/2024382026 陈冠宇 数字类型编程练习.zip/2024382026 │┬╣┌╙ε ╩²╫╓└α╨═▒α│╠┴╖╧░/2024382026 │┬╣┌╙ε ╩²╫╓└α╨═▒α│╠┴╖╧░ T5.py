weight = input("input weight: ")
weight = float(weight)
for i in range(10):
    print(f"year {i+1} the weight on earth is {weight},the weight on moon is {weight*0.165}")
    weight+=0.5
