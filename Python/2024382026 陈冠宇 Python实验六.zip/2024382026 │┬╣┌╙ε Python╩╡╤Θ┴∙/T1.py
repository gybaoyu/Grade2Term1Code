total = 0
count = 0

while total <= 100:
    count += 1
    total += count

print(f"前{count}个自然数之和为{total}，刚好超过100")