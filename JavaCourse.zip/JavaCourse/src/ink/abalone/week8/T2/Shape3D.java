package ink.abalone.week8.T2;

public abstract class Shape3D {
    public abstract double calculateVolume();
    public abstract double calculateSurfaceArea();
}
