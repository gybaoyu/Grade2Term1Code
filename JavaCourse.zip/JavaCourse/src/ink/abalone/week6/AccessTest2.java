package ink.abalone.week6;

public class AccessTest2 {
    public static void main(String[] args) {
        Student s2 = new Student();
        s2.setNum("00000002");
    }
}
